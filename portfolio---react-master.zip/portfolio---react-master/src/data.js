export const soloProjects = [
  {
    id: 1,
    title: 'Bookstore',
    img: 'assets/bookstore.png',
    link: 'https://melodic-boba-111583.netlify.app/',
    github: 'https://github.com/Meri-MG/bookstore---react',
  },
  {
    id: 2,
    title: '',
    img: '',
    link: 'https://melodic-boba-111583.netlify.app/',
    github: '',
  },
  {
    id: 3,
    title: '',
    img: '',
    link: 'https://melodic-boba-111583.netlify.app/',
    github: '',
  },
  {
    id: 4,
    title: '',
    img: '',
    link: 'https://melodic-boba-111583.netlify.app/',
    github: '',
  },
  {
    id: 5,
    title: '',
    img: '',
    link: 'https://melodic-boba-111583.netlify.app/',
    github: '',
  },
  {
    id: 6,
    title: '',
    img: '',
    link: 'https://melodic-boba-111583.netlify.app/',
    github: '',
  },
];
